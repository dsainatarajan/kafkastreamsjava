package com.duratech.kafkademo.springkafkastreams;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringkafkastreamsApplicationTests {

	@Test
	void contextLoads() {
	}

}
