package com.duratech.kafkademo.springkafkastreams;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringkafkastreamsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringkafkastreamsApplication.class, args);
	}

}
